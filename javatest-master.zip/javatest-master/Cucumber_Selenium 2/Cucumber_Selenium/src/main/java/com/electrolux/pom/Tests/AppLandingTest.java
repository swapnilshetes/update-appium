package com.electrolux.pom.Tests;

public class AppLandingTest {

}
