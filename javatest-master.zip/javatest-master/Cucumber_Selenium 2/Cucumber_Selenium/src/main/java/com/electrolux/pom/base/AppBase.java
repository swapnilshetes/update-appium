package com.electrolux.pom.base;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.electrolux.pom.AppHomepageObject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class AppBase {

	private AppiumDriver<MobileElement> driver;
	AppHomepageObject appHomepage;

	@Parameters({ "device", "app_package", "activity", "version", "appiumServer" })
	@BeforeTest
	public void deviceSetUp(String device, String app_package, String activity, String version, String appiumServer)
			throws InterruptedException, MalformedURLException, InterruptedException {

		DesiredCapabilities cap = DesiredCapabilities.android();
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, device);
		cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
		cap.setCapability(MobileCapabilityType.APP, "C:\\swapnil\\apk\\app-debug.apk");
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME, Platform.ANDROID);
		cap.setCapability(MobileCapabilityType.BROWSER_NAME, BrowserType.ANDROID);
		cap.setCapability(MobileCapabilityType.VERSION, version);

		URL url = new URL(appiumServer);
		setDriver(new AndroidDriver<MobileElement>(url, cap));
		getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	public AppiumDriver<MobileElement> getDriver() {
		return driver;
	}

	public void setDriver(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
	}

}
