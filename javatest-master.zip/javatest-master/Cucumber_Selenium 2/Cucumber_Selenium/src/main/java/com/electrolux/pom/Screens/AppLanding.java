package com.electrolux.pom.Screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.electrolux.pom.base.AppBase;

import io.appium.java_client.MobileBy;

public class AppLanding extends AppBase {

public void navigateToLoginPage(){
		
		WebDriverWait wait = new WebDriverWait(new AppBase().getDriver(), 10);
		WebElement continueButton = wait.until(ExpectedConditions
				.visibilityOfElementLocated((MobileBy.xpath("//android.view.View[@content-desc=\"CONTINUE\"]"))));
		continueButton.click();
		
	}
	
}
